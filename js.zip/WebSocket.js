(function(){
  const _WS = window.WebSocket;
  window.WebSocket = function(...args){
    const ws = new _WS(...args);
    console.log('%c[WS OPEN]', 'color:#0ff', args[0]);
    ws.addEventListener('message', e => console.log('%c[WS IN]', 'color:#0f0', e.data));
    const _send = ws.send.bind(ws);
    ws.send = function(data){ console.log('%c[WS OUT]', 'color:#ff0', data); return _send(data); };
    return ws;
  };
  window.WebSocket.prototype = _WS.prototype;
})();