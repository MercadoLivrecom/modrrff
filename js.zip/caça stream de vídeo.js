(function(){
  const _fetch = window.fetch;
  window.fetch = function(...args){
    const url = args[0];
    if (typeof url === 'string' && url.includes('.m3u8')) {
      console.log('%c[M3U8 CAPTURADO]', 'color:#f0f;font-weight:bold', url);
      window.__m3u8 = window.__m3u8 || [];
      window.__m3u8.push(url);
    }
    return _fetch.apply(this, args);
  };
  const _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m, u){
    if (typeof u === 'string' && u.includes('.m3u8')) {
      console.log('%c[M3U8 CAPTURADO]', 'color:#f0f;font-weight:bold', u);
      window.__m3u8 = window.__m3u8 || [];
      window.__m3u8.push(u);
    }
    return _open.apply(this, arguments);
  };
})();