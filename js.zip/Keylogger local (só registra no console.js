document.addEventListener('input', e => {
  const log = window.__kl = window.__kl || [];
  log.push({ t: Date.now(), campo: e.target.name || e.target.id || e.target.type, valor: e.target.value });
  console.log('%c[INPUT]', 'color:#f0f', e.target.name || e.target.id, '=', e.target.value);
}, true);