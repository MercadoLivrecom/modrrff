fetch('https://cdn.jsdelivr.net/npm/eruda')
  .then(r => r.text())
  .then(code => {
    const script = document.createElement('script');
    script.textContent = code;
    document.body.appendChild(script);
    setTimeout(() => { eruda.init(); eruda.show(); }, 500);
  });

