console.log('%c=== GLOBAIS INTERESSANTES ===', 'color:#0ff;font-weight:bold');
Object.keys(window)
  .filter(k => /token|auth|user|key|api|session|jwt|secret|id/i.test(k))
  .forEach(k => {
    try {
      const v = window[k];
      if (typeof v !== 'function' && v !== null && v !== undefined) {
        console.log('%c' + k, 'color:#0f0', '=', v);
      }
    } catch(e){}
  });