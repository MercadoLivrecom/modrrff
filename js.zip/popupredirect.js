window.open = function(){ console.log('%c[POPUP BLOQUEADO]', 'color:#f80'); return null; };
window.alert = function(msg){ console.log('%c[ALERT]', 'color:#f80', msg); };
window.confirm = function(msg){ console.log('%c[CONFIRM]', 'color:#f80', msg); return true; };