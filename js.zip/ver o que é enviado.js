document.querySelectorAll('form').forEach((f, i) => {
  f.addEventListener('submit', e => {
    const data = new FormData(f);
    const obj = {};
    data.forEach((v, k) => obj[k] = v);
    console.log('%c[FORM ' + i + ']', 'color:#f80', f.action, obj);
  }, true);
});