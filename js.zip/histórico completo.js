console.log('%c=== COOKIES ===', 'color:#0ff');
console.log(document.cookie);
console.log('%c=== LOCALSTORAGE ===', 'color:#0ff');
console.log(JSON.stringify(localStorage, null, 2));
console.log('%c=== SESSIONSTORAGE ===', 'color:#0ff');
console.log(JSON.stringify(sessionStorage, null, 2));