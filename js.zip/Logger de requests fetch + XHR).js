(function(){
  const _fetch = window.fetch;
  window.fetch = function(...args){
    console.log('%c[FETCH]', 'color:#0ff', args[0], args[1] || '');
    return _fetch.apply(this, args).then(r => {
      console.log('%c[RESP]', 'color:#0f0', r.status, r.url);
      return r;
    });
  };
  const _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m, u){
    console.log('%c[XHR]', 'color:#ff0', m, u);
    return _open.apply(this, arguments);
  };
})();